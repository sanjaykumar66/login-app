package com.example.hp.login;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;


public class MainActivity extends AppCompatActivity {

    private ImageView IconImageView;
    private TextView Signup,ForgetPassword,skipTextView,WelcomeTextView;
    private ProgressBar loadingProgressBar;
    private RelativeLayout rootView, afterAnimationView;
    private ImageView loginbutton;
    private int flags=0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        IconImageView = findViewById(R.id.IconImageView);
        loadingProgressBar = findViewById(R.id.loadingProgressBar);
        rootView = findViewById(R.id.rootView);
        afterAnimationView = findViewById(R.id.afterAnimationView);
        WelcomeTextView=findViewById(R.id.WelcomeTextView);
        ForgetPassword=findViewById(R.id.ForgetPassword);
        loginbutton=findViewById(R.id.login);
        Signup=findViewById(R.id.SignUp);
        loginbutton.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Animation slide;
              // if(event.getAction()==MotionEvent.ACTION)
                if(flags==0)
                {
                    loginbutton.setImageResource(R.drawable.light);
                    NightThemeMode();
                    slide= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slideup);
                    //loginbutton.startAnimation(slide);
                }
                else
                {
                    loginbutton.setImageResource(R.drawable.dark);
                    DayThemeMode();
                }
                new CountDownTimer(1000,100){

                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                       // loginbutton.setImageResource(R.drawable.login);
                    }
                }.start();
                return false;
            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(i);
            }
        });
        new CountDownTimer(5000, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                loadingProgressBar.setVisibility(GONE);
                startAnimation();
            }
            @Override
            public void onFinish() {

            }
        }.start();
    }
@SuppressLint("ResourceAsColor")
private void DayThemeMode(){
    IconImageView.setImageResource(R.drawable.night);
    afterAnimationView.setBackgroundColor(getResources().getColor(R.color.dayBackground));
    WelcomeTextView.setTextColor(getResources().getColor(R.color.nightBackground));
    rootView.setBackgroundColor(getResources().getColor(R.color.dayBackground));
    Signup.setTextColor(getResources().getColor(R.color.colorTextView));
    ForgetPassword.setTextColor(getResources().getColor(R.color.colorTextView));
    flags=0;

}
    @SuppressLint("ResourceAsColor")
    private void NightThemeMode() {
        IconImageView.setImageResource(R.drawable.day);
        rootView.setBackgroundColor(getResources().getColor(R.color.nightBackground));
        afterAnimationView.setBackgroundColor(getResources().getColor(R.color.nightBackground));
        WelcomeTextView.setTextColor(getResources().getColor(R.color.Textcolor));
        Signup.setTextColor(getResources().getColor(R.color.Textcolor));
        ForgetPassword.setTextColor(getResources().getColor(R.color.Textcolor));
        rootView.setBackgroundColor(getResources().getColor(R.color.nightBackground));
        flags=1;
    }



    private void startAnimation() {
        ViewPropertyAnimator viewPropertyAnimator = IconImageView.animate();
        viewPropertyAnimator.x(50f);
        viewPropertyAnimator.y(100f);
        viewPropertyAnimator.setDuration(1000);
        viewPropertyAnimator.setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                afterAnimationView.setVisibility(VISIBLE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }
    private long backPressedTime;
    private Toast backToast;
    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
            backToast.show();
        }

        backPressedTime = System.currentTimeMillis();
    }
}