package com.example.hp.login;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class Main2Activity extends AppCompatActivity {
    private ImageView IconImageView1,login1;
    private TextView Signup1,skipTextView1,WelcomeTextView1;
    private ProgressBar loadingProgressBar1;
    private RelativeLayout rootView1, afterAnimationView1;
    private Button loginButton1;
    private int flag=0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main2);
        IconImageView1 = findViewById(R.id.IconImageView1);
        loadingProgressBar1 = findViewById(R.id.loadingProgressBar1);
        rootView1 = findViewById(R.id.rootView1);
        afterAnimationView1 = findViewById(R.id.afterAnimationView1);
        WelcomeTextView1=findViewById(R.id.WelcomeTextView1);
        loginButton1=findViewById(R.id.loginButton1);
        Signup1=findViewById(R.id.SignUp1);
        Signup1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });
        login1=findViewById(R.id.login1);
        login1.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Animation slide;
                // if(event.getAction()==MotionEvent.ACTION)
                if(flag==0)
                {
                    login1.setImageResource(R.drawable.light);
                    NightThemeMode1();
                    slide= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slideup);
                    //loginbutton.startAnimation(slide);
                }
                else
                {
                    login1.setImageResource(R.drawable.dark);
                    DayThemeMode1();
                }
                new CountDownTimer(1000,100){

                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    @Override
                    public void onFinish() {
                        // loginbutton.setImageResource(R.drawable.login);
                    }
                }.start();
                return false;
            }
        });
        new CountDownTimer(5000, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                loadingProgressBar1.setVisibility(GONE);
                startAnimation();
            }

            @Override
            public void onFinish() {

            }
        }.start();
    }
    @SuppressLint("ResourceAsColor")
    private void DayThemeMode1(){
        IconImageView1.setImageResource(R.drawable.night);
        afterAnimationView1.setBackgroundColor(getResources().getColor(R.color.dayBackground));
        WelcomeTextView1.setTextColor(getResources().getColor(R.color.nightBackground));
        Signup1.setTextColor(getResources().getColor(R.color.colorTextView));
        rootView1.setBackgroundColor(getResources().getColor(R.color.dayBackground));
        loginButton1.setTextColor(getResources().getColor(R.color.colorAccent));
        flag=0;
    }
    @SuppressLint("ResourceAsColor")
    private void NightThemeMode1() {
        IconImageView1.setImageResource(R.drawable.day);
        rootView1.setBackgroundColor(getResources().getColor(R.color.nightBackground));
        afterAnimationView1.setBackgroundColor(getResources().getColor(R.color.nightBackground));
        WelcomeTextView1.setTextColor(getResources().getColor(R.color.Textcolor));
        Signup1.setTextColor(getResources().getColor(R.color.Textcolor));
        loginButton1.setTextColor(getResources().getColor(R.color.Textcolor));
        flag=1;

    }
    private void startAnimation() {
        ViewPropertyAnimator viewPropertyAnimator = IconImageView1.animate();
        viewPropertyAnimator.x(50f);
        viewPropertyAnimator.y(100f);
        viewPropertyAnimator.setDuration(1000);
        viewPropertyAnimator.setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                afterAnimationView1.setVisibility(VISIBLE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }
    private long backPressedTime;
    private Toast backToast;
    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
            backToast.show();
        }

        backPressedTime = System.currentTimeMillis();
    }
    }

